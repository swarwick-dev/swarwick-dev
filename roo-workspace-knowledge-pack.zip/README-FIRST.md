
Fresh undocumented project workflow

1. Copy .roo into project root

2. First prompt:

Review the workspace and bootstrap project knowledge.

Run:
- bootstrap-codebase
- bootstrap-system-map
- bootstrap-api-map
- bootstrap-glossary
- bootstrap-dependency-map

Populate .roo/knowledge

3. After large changes:

Update workspace knowledge using workspace-maintainer

4. Periodically:

Review stale knowledge and refine summaries.
