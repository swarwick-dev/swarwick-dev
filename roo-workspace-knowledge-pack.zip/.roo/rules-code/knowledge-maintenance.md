
# Knowledge Maintenance

When creating or modifying:

- architecture
- public APIs
- threading
- serialization
- dependencies
- major systems

Automatically:

1. Update existing knowledge
2. Create missing knowledge
3. Update decision records
4. Keep summaries concise
