
# Project Bootstrap

Before scanning large code areas:

1. Read knowledge/project-index.md
2. Read existing summaries
3. Only scan implementation if missing information
