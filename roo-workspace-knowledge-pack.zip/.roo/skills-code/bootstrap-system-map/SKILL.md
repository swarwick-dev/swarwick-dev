---
name: bootstrap-system-map
description: Generate system summaries from source code.
---

# Bootstrap Systems

Generate:

Purpose
Major classes
Responsibilities
Relationships
Thread model
Dependencies
Files
