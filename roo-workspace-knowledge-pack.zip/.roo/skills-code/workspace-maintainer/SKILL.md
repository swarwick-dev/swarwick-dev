---
name: workspace-maintainer
description: Use after implementing or modifying significant functionality.
---

# Workspace Maintainer

After changes:

1. Identify modified systems
2. Update architecture knowledge
3. Update APIs
4. Update decisions
5. Update troubleshooting notes
6. Remove stale knowledge
7. Keep summaries concise
