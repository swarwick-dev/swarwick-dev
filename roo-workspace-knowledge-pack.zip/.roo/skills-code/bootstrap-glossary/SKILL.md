---
name: bootstrap-glossary
description: Extract project terminology and acronyms.
---

# Bootstrap Glossary

Generate terms, acronyms, system names and internal jargon.
