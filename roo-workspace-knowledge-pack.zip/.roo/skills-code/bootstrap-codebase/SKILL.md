---
name: bootstrap-codebase
description: Use when creating an initial workspace knowledge base from an undocumented project.
---

# Bootstrap Codebase

1. Scan folder structure
2. Identify modules/plugins/libraries/tests
3. Determine startup flow and dependencies
4. Generate project overview
