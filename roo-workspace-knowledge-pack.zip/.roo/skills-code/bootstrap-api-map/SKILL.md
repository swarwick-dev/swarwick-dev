---
name: bootstrap-api-map
description: Extract public APIs.
---

# Bootstrap API Map

Extract:

Public classes
Methods
Ownership
Thread safety
Examples
