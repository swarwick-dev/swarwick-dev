#pragma once
#include "CDBField.h"

enum class OperatorType {
    Equal,
    NotEqual,
    Greater,
    Less,
    Like
};

inline CString ToOperatorString(OperatorType op) {
    switch (op) {
        case OperatorType::Equal: return "=";
        case OperatorType::NotEqual: return "<>";
        case OperatorType::Greater: return ">";
        case OperatorType::Less: return "<";
        case OperatorType::Like: return "LIKE";
        default: return "?";
    }
}

enum class CQBFilterRHS {
    Field,
    Value
};

class CQBFilter {
public:
    CDBField left;
    CDBField rightField;
    CString rightValue;
    OperatorType op;
    CQBFilterRHS rhsType = CQBFilterRHS::Value;

    bool isBound() const { return rhsType == CQBFilterRHS::Value; }

    CString toSQLString(bool forBinding = false) const {
        CString sql;
        sql += left.getFullName() + " " + ToOperatorString(op) + " ";
        sql += (isBound() && forBinding) ? "?" : (isBound() ? rightValue : rightField.getFullName());
        return sql;
    }
};