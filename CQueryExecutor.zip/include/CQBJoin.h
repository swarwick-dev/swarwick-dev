#pragma once
#include "CDBField.h"

class CDBTable {
private:
    CString m_name;
public:
    CDBTable() {}
    CDBTable(const CString& name) : m_name(name) {}
    CString getName() const { return m_name; }
};

class CQBJoin {
public:
    CDBTable toTable;
    CDBField fromField;
    CDBField toField;

    CString to_string() const {
        return "JOIN " + toTable.getName() + " ON " +
               fromField.getFullName() + " = " + toField.getFullName();
    }
};