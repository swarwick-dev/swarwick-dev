#pragma once
#include <afx.h>

class CDBField {
private:
    CString m_name;
    CString m_tableAlias;
    CString m_value;
public:
    CDBField() {}
    CDBField(const CString& name, const CString& tableAlias = "") :
        m_name(name), m_tableAlias(tableAlias) {}

    CString getName() const { return m_name; }
    CString getTableAlias() const { return m_tableAlias; }
    CString getFullName() const {
        return m_tableAlias.IsEmpty() ? m_name : m_tableAlias + "." + m_name;
    }

    void SetValue(const CString& val) { m_value = val; }
    CString GetValue() const { return m_value; }

    CString to_string() const { return getFullName(); }
};