#pragma once

#include <windows.h>
#include <sqlext.h>
#include <map>
#include <vector>
#include <afx.h>
#include "CDBField.h"
#include "CQBJoin.h"
#include "CQBFilter.h"

class CQueryExecutor {
public:
    CQueryExecutor(SQLHDBC hDbc);
    ~CQueryExecutor();

    BOOL ExecuteSelect(const CString& baseTable,
                       const CArray<CDBField, CDBField&>& outputFields,
                       const std::vector<CQBJoin>& joins,
                       const std::vector<CQBFilter>& filters);

    BOOL SelectNextRow(CArray<CDBField, CDBField&>& targetRow);
    void Reset();

private:
    struct CachedQuery {
        CString query;
        SQLHSTMT hStmt;
        std::vector<CString> boundValues;
        std::vector<void*> fetchBuffers;
    };

    CString BuildQuery(const CString& baseTable,
                       const CArray<CDBField, CDBField&>& fields,
                       const std::vector<CQBJoin>& joins,
                       const std::vector<CQBFilter>& filters,
                       std::vector<CString>& outBindValues);

    void BindFields(const CArray<CDBField, CDBField&>& fields);
    void BindParameters(const std::vector<CString>& bindValues);
    void AllocateFetchBuffers(const CArray<CDBField, CDBField&>& fields);

    SQLHDBC m_hDbc;
    SQLHSTMT m_hStmt = nullptr;
    CachedQuery* m_currentQuery = nullptr;
    std::map<CString, CachedQuery> m_queryCache;
};