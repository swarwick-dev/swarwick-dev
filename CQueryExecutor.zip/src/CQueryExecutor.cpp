#include "CQueryExecutor.h"
#include <sstream>

CQueryExecutor::CQueryExecutor(SQLHDBC hDbc) : m_hDbc(hDbc) {}

CQueryExecutor::~CQueryExecutor() {
    for (auto& [_, q] : m_queryCache) {
        SQLFreeHandle(SQL_HANDLE_STMT, q.hStmt);
        for (void* buf : q.fetchBuffers) free(buf);
    }
}

CString CQueryExecutor::BuildQuery(const CString& baseTable,
                                   const CArray<CDBField, CDBField&>& fields,
                                   const std::vector<CQBJoin>& joins,
                                   const std::vector<CQBFilter>& filters,
                                   std::vector<CString>& outBindValues) {
    CString sql = "SELECT ";
    for (int i = 0; i < fields.GetSize(); ++i) {
        if (i > 0) sql += ", ";
        sql += fields[i].getFullName();
    }

    sql += " FROM " + baseTable;

    for (const auto& j : joins) {
        sql += " JOIN " + j.toTable.getName();
        sql += " ON " + j.fromField.getFullName() + " = " + j.toField.getFullName();
    }

    if (!filters.empty()) {
        sql += " WHERE ";
        for (size_t i = 0; i < filters.size(); ++i) {
            if (i > 0) sql += " AND ";
            sql += filters[i].toSQLString(true);
            if (filters[i].isBound()) {
                outBindValues.push_back(filters[i].rightValue);
            }
        }
    }

    return sql;
}

BOOL CQueryExecutor::ExecuteSelect(const CString& baseTable,
                                   const CArray<CDBField, CDBField&>& outputFields,
                                   const std::vector<CQBJoin>& joins,
                                   const std::vector<CQBFilter>& filters) {
    std::vector<CString> bindVals;
    CString query = BuildQuery(baseTable, outputFields, joins, filters, bindVals);

    if (m_queryCache.count(query) == 0) {
        CachedQuery cq;
        SQLAllocHandle(SQL_HANDLE_STMT, m_hDbc, &cq.hStmt);
        cq.query = query;
        SQLPrepare(cq.hStmt, (SQLCHAR*)(LPCSTR)query, SQL_NTS);
        m_queryCache[query] = std::move(cq);
    }

    m_currentQuery = &m_queryCache[query];
    m_hStmt = m_currentQuery->hStmt;

    BindParameters(bindVals);
    AllocateFetchBuffers(outputFields);
    BindFields(outputFields);

    return SQLExecute(m_hStmt) == SQL_SUCCESS;
}

void CQueryExecutor::BindParameters(const std::vector<CString>& bindValues) {
    for (size_t i = 0; i < bindValues.size(); ++i) {
        SQLBindParameter(m_hStmt, (SQLUSMALLINT)(i + 1), SQL_PARAM_INPUT,
                         SQL_C_CHAR, SQL_VARCHAR, 0, 0,
                         (SQLPOINTER)(LPCSTR)bindValues[i],
                         bindValues[i].GetLength(), nullptr);
    }
}

void CQueryExecutor::AllocateFetchBuffers(const CArray<CDBField, CDBField&>& fields) {
    auto& buffers = m_currentQuery->fetchBuffers;
    for (void* buf : buffers) free(buf);
    buffers.clear();

    for (int i = 0; i < fields.GetSize(); ++i) {
        void* buffer = malloc(256);
        buffers.push_back(buffer);
    }
}

void CQueryExecutor::BindFields(const CArray<CDBField, CDBField&>& fields) {
    for (int i = 0; i < fields.GetSize(); ++i) {
        SQLBindCol(m_hStmt, i + 1, SQL_C_CHAR,
                   m_currentQuery->fetchBuffers[i], 256, nullptr);
    }
}

BOOL CQueryExecutor::SelectNextRow(CArray<CDBField, CDBField&>& targetRow) {
    if (SQLFetch(m_hStmt) != SQL_SUCCESS) return FALSE;

    for (int i = 0; i < targetRow.GetSize(); ++i) {
        targetRow[i].SetValue((char*)m_currentQuery->fetchBuffers[i]);
    }
    return TRUE;
}