#include "DisintegrationComponent.h"
#include "GameFramework/Actor.h"

UDisintegrationComponent::UDisintegrationComponent()
{
    PrimaryComponentTick.bCanEverTick = false;
    SetIsReplicatedByDefault(true);
}

void UDisintegrationComponent::BeginPlay()
{
    Super::BeginPlay();
}

void UDisintegrationComponent::PlayDisintegration()
{
    if (GetOwner()->HasAuthority())
    {
        Multicast_PlayDisintegration();
    }
}

void UDisintegrationComponent::Multicast_PlayDisintegration_Implementation()
{
    if (!VoxelDisintegrationEffect) return;

    AActor* Owner = GetOwner();
    if (!Owner) return;

    if (UPrimitiveComponent* Mesh = Cast<UPrimitiveComponent>(Owner->GetComponentByClass(UPrimitiveComponent::StaticClass())))
    {
        Mesh->SetVisibility(false, true); // Hide mesh and children
    }

    UNiagaraFunctionLibrary::SpawnSystemAtLocation(
        GetWorld(),
        VoxelDisintegrationEffect,
        Owner->GetActorLocation(),
        Owner->GetActorRotation()
    );
}
