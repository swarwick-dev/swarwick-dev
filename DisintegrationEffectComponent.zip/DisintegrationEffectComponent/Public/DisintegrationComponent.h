#pragma once

#include "CoreMinimal.h"
#include "Components/ActorComponent.h"
#include "NiagaraSystem.h"
#include "NiagaraFunctionLibrary.h"
#include "DisintegrationComponent.generated.h"

UCLASS(ClassGroup = (Custom), meta = (BlueprintSpawnableComponent))
class YOURGAME_API UDisintegrationComponent : public UActorComponent
{
    GENERATED_BODY()

public:
    UDisintegrationComponent();

    UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "Disintegration")
    UNiagaraSystem* VoxelDisintegrationEffect;

    UFUNCTION(BlueprintCallable, Category = "Disintegration")
    void PlayDisintegration();

    UFUNCTION(NetMulticast, Reliable)
    void Multicast_PlayDisintegration();

protected:
    virtual void BeginPlay() override;
};
