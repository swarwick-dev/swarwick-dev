#include "FocusMessageV2.h"

#include <iostream>

struct LegacyOpaqueStruct
{
    int32_t orderId;
    double price;
    uint32_t quantity;
};

int main()
{
    using namespace FocusTransport;

    Message msg;
    msg.ReserveFields(5);

    msg.AddString(1, "Symbol", "ABC.L");
    msg.AddInt32(2, "Quantity", 100);
    msg.AddDouble(3, "Price", 123.45);
    msg.AddXml(4, "XmlDetails", "<order><side>buy</side></order>");

    LegacyOpaqueStruct legacy{42, 123.45, 100};
    msg.AddOpaqueStruct(5, "LegacyStruct", legacy);

    std::vector<uint8_t> payload;
    msg.SerializeInto(payload);

    // Send payload.data(), payload.size() over NATS.
    // natsConnection_Publish(conn, subject.c_str(), payload.data(), payload.size());

    DeserializeResult result{};
    Message rx = Message::Deserialize(payload.data(), payload.size(), &result);

    if (result != DeserializeResult::Ok)
    {
        std::cerr << "Deserialize failed\n";
        return 1;
    }

    std::string_view symbol;
    int32_t quantity{};
    LegacyOpaqueStruct decoded{};

    if (rx.TryGetStringView(1, symbol))
        std::cout << "Symbol: " << symbol << "\n";

    if (rx.TryGetInt32(2, quantity))
        std::cout << "Quantity: " << quantity << "\n";

    if (rx.TryGetOpaqueStruct(5, decoded))
        std::cout << "Legacy order id: " << decoded.orderId << "\n";

    return 0;
}
