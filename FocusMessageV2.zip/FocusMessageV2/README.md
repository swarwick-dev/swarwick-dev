# FocusMessage V2

High-performance binary field message for a TIBRV-style wrapper over NATS.

## Files

- `FocusMessageV2.h` - header-only message class
- `Example.cpp` - basic usage example

## Recommended send flow

```cpp
FocusTransport::Message msg;
msg.ReserveFields(8);

msg.AddString(1, "Subject", "ABC.L");
msg.AddInt32(2, "Quantity", 100);
msg.AddOpaque(3, "LegacyBlob", data, size);

std::vector<uint8_t> payload;
msg.SerializeInto(payload);

natsConnection_Publish(conn, subject.c_str(), payload.data(), payload.size());
```

## Recommended receive flow

```cpp
FocusTransport::DeserializeResult result{};
auto msg = FocusTransport::Message::Deserialize(data, size, &result);

if (result != FocusTransport::DeserializeResult::Ok)
{
    // reject message
}

int32_t quantity{};
if (msg.TryGetInt32(2, quantity))
{
    // use quantity
}
```

## Notes

- Use `TryGet*` in hot paths.
- Use throwing getters only for convenience/config paths.
- Opaque structs must be trivially copyable.
- The wire format is binary and uses a fixed endian marker.
- Thread safety is optional:

```cpp
auto msg = FocusTransport::Message::CreateThreadSafe();
```

For lowest latency, keep thread safety off and use message instances as single-owner objects.
