# Modern C++ Code Style Rules

These rules apply to C++ code generation, refactoring, review, and debugging.

## Language Standard

- Prefer C++20.
- Use C++17-compatible alternatives only when the project requires it.
- Do not introduce non-standard compiler extensions unless already used by the project.
- For Windows-focused code, support MSVC cleanly.

## General Style

- Write production-quality, maintainable C++.
- Prefer clarity first, then performance.
- Use RAII for ownership and cleanup.
- Avoid raw owning pointers.
- Avoid manual `new` and `delete`.
- Avoid global mutable state.
- Avoid macros unless needed for platform, build, logging, or export/import declarations.
- Prefer `constexpr`, `const`, and immutability where practical.
- Prefer early returns over deeply nested code.
- Prefer narrow scopes for variables and locks.

## Naming Conventions

Use modern C++ naming unless a project already has a stronger local convention.

- Types/classes/structs/enums: `PascalCase`
- Functions/methods: `PascalCase`
- Local variables and parameters: `camelCase`
- Private member variables: `m_camelCase`
- Static variables: `s_camelCase`
- Constants: `kPascalCase`
- Enum values: `PascalCase`
- Template parameters: short PascalCase such as `T`, `TValue`, `TAllocator`
- Interfaces/abstract base classes: descriptive names, no forced `I` prefix unless existing code uses it.

## File Naming

- Header files: `.h` or `.hpp`, matching project convention.
- Source files: `.cpp`.
- One primary class per file unless tightly coupled.
- Match file name to primary type.

## Headers

- Use `#pragma once`.
- Include only what is required.
- Prefer forward declarations in headers where possible.
- Do not put broad `using namespace` declarations in headers.
- Keep template and inline code intentional and minimal.
- Public headers must be self-contained.

## Ownership and Lifetime

- Use stack values by default.
- Use `std::unique_ptr` for exclusive heap ownership.
- Use `std::shared_ptr` only for genuinely shared lifetime.
- Use raw pointers only for non-owning nullable references.
- Use references for non-null borrowed objects.
- Use `std::span` for borrowed contiguous ranges.
- Use `std::string_view` for borrowed string input where lifetime is clear.

## Error Handling

- Do not throw exceptions across DLL boundaries.
- For library APIs, prefer explicit result/status types.
- Preserve original error information where possible.
- Include contextual error messages.
- Validate external input.
- Treat deserialization input as untrusted.

## Performance

- Avoid allocations on hot paths.
- Prefer contiguous storage.
- Avoid unnecessary copies.
- Use move semantics deliberately.
- Do not return references to temporary data.
- Avoid virtual dispatch in hot paths unless the design needs runtime polymorphism.
- Prefer measuring before optimizing.
- Mention likely performance trade-offs when making design choices.

## Concurrency

- Make thread-safety guarantees explicit.
- Protect shared mutable state.
- Keep lock scopes small.
- Avoid calling user callbacks while holding locks.
- Avoid detached threads.
- Provide deterministic shutdown for worker threads.
- Use atomics only when the memory-ordering requirements are understood.

## DLL / ABI Rules

- Avoid exposing STL containers, exceptions, or compiler-specific types across unstable DLL boundaries.
- Prefer pImpl or C-compatible exported boundaries where ABI stability matters.
- Keep exported interfaces versioned.
- Do not allocate memory in one module and require another module to free it unless the allocator contract is explicit.

## Testing Expectations

- New behaviour should include tests where practical.
- Add regression tests for bug fixes.
- Test edge cases, invalid input, boundary values, and serialization round trips.
- For concurrency code, include shutdown, timeout, and contention cases.
- For performance code, separate correctness tests from benchmarks.

## Response Behaviour

When producing code:

1. Prefer complete drop-in files over fragments when the user asks for implementation.
2. Include required includes.
3. Keep comments useful, not noisy.
4. Explain important design trade-offs briefly.
5. Highlight any assumptions.
6. Mention build-system changes if new files or dependencies are required.
