# Architecture Rules

1. Public interfaces remain stable unless the user explicitly requests a breaking change.
2. Dependencies flow inward:
   - API
   - Services
   - Internal implementation
3. Avoid cyclic dependencies.
4. Separate transport, serialization, business logic, and persistence.
5. Favor composition over inheritance.
6. Avoid singleton abuse.
7. Minimize global state.
8. Hot-path code should minimize allocations, locks, and virtual dispatch.
9. Keep infrastructure concerns isolated from domain logic.
10. Make ownership, lifetime, threading, and error contracts explicit.
11. Prefer interfaces that are easy to test with fakes/mocks.
12. Do not invent new architectural patterns in an existing codebase unless they solve a concrete problem.
