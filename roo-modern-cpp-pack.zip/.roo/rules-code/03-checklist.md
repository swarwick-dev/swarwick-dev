# Before Returning C++ Code

Before returning C++ code, check:

- Includes compile.
- No missing headers.
- Const correctness checked.
- Copy/move semantics reviewed.
- Thread safety reviewed.
- Lifetime issues checked.
- Exception behavior reviewed.
- DLL boundary checked.
- Serialization validated where applicable.
- Hot-path allocations minimized where applicable.
- Unit tests suggested where practical.
- No hidden global state.

When generating code, prefer complete drop-in replacement files:

- Header
- CPP
- Required build changes
- Usage example
