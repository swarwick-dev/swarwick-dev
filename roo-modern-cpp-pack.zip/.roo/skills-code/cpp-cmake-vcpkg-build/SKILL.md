---
name: cpp-cmake-vcpkg-build
description: Use when creating or modifying CMake, vcpkg manifests, build presets, Visual Studio C++ projects, CI build scripts, or Windows C++ build configuration.
---

# CMake / vcpkg / Build Skill

Rules:

1. Prefer modern target-based CMake.
2. Avoid global include directories and global compile definitions where possible.
3. Use `target_link_libraries`, `target_include_directories`, and `target_compile_features`.
4. Prefer `CMakePresets.json` for reproducible local and CI builds.
5. Keep Debug, Release, RelWithDebInfo, and ASan/analysis configurations practical.
6. For vcpkg, prefer manifest mode with `vcpkg.json`.
7. Keep third-party dependencies explicit and minimal.
8. Ensure Windows/MSVC settings are correct for runtime library, warnings, and DLL exports.
9. Do not hide compiler warnings unless there is a documented reason.
10. Mention required commands to configure, build, test, and package.
