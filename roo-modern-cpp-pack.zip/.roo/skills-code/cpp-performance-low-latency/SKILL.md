---
name: cpp-performance-low-latency
description: Use when optimizing C++ code for latency, throughput, allocation reduction, cache locality, messaging, serialization, queues, or hot-path processing.
---

# C++ Performance / Low Latency Skill

Prioritize measurement-led changes. Avoid speculative rewrites unless the likely bottleneck is clear.

Rules:

1. Identify hot paths before changing architecture.
2. Avoid allocations in steady-state hot paths.
3. Prefer contiguous memory and cache-friendly layouts.
4. Avoid unnecessary copies; use move semantics and views carefully.
5. Keep lock duration minimal.
6. Prefer batching where it reduces syscall, network, or synchronization overhead.
7. Watch false sharing, contention, branch predictability, and memory ownership.
8. Do not sacrifice correctness for micro-optimisation.
9. Suggest benchmarks or instrumentation when performance claims are made.
10. For serialization, prefer explicit binary layouts, versioning, bounds checks, and endian awareness.
