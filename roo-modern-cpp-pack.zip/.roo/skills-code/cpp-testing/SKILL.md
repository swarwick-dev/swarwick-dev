---
name: cpp-testing
description: Use when creating or improving C++ unit tests, integration tests, mocks, harnesses, benchmarks, or regression tests.
---

# C++ Testing Skill

Rules:

1. Prefer deterministic tests.
2. Use dependency injection for external systems.
3. Separate unit tests from integration tests.
4. Mock time, transport, filesystem, network, and process boundaries.
5. Test serialization round trips and malformed input.
6. Add regression tests for every fixed bug.
7. Prefer small focused tests with clear arrange/act/assert structure.
8. Include stress or soak tests for concurrency-sensitive components.
9. For performance-sensitive code, add microbenchmarks separately from correctness tests.
