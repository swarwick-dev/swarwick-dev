---
name: modern-cpp-implementation
description: Use when writing or refactoring modern C++17/C++20 production code, especially headers, source files, classes, RAII wrappers, DLL-safe interfaces, or performance-sensitive components.
---

# Modern C++ Implementation Skill

When modifying C++ code:

1. Prefer C++20 where available, otherwise remain compatible with the project standard.
2. Use RAII for all resource ownership.
3. Prefer value semantics unless ownership or polymorphism requires otherwise.
4. Prefer `std::unique_ptr` for exclusive ownership and avoid raw owning pointers.
5. Avoid hidden global state and static mutable state.
6. Keep headers minimal:
   - forward declare where possible
   - avoid unnecessary includes
   - keep inline code small
7. Separate interface from implementation.
8. Use `noexcept` where failure is impossible or where move operations should not throw.
9. Prefer `std::span`, `std::string_view`, `std::array`, `std::vector`, and strongly typed enums.
10. Avoid exceptions across DLL boundaries.
11. For Windows DLL APIs, expose stable C-style or pImpl boundaries where ABI stability matters.
12. Always consider lifetime, ownership, threading, allocation behaviour, error reporting, and testability.

Before returning code, check it for:

- missing includes
- const correctness
- move/copy correctness
- ABI issues
- data races
- unnecessary heap allocations
- avoidable virtual dispatch
