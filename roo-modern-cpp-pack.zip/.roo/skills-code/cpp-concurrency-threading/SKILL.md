---
name: cpp-concurrency-threading
description: Use when reviewing or writing C++ threading, atomics, queues, worker threads, condition variables, lock-free code, async processing, or shared-state logic.
---

# C++ Concurrency Skill

Rules:

1. Make ownership and thread affinity explicit.
2. Prefer message passing or immutable data over shared mutable state.
3. Use mutexes unless atomics are clearly justified.
4. Use `std::atomic` with explicit memory-order reasoning only where required.
5. Avoid detached threads.
6. Ensure shutdown paths are deterministic.
7. Avoid callbacks holding locks.
8. Protect all shared mutable data.
9. Consider cancellation, timeouts, backpressure, and spurious wakeups.
10. Document the threading contract on public APIs.
