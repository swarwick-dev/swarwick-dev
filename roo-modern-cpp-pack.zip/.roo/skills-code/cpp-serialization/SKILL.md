---
name: cpp-serialization
description: Use when creating binary protocols, message formats, transport payloads, deserialization, or field encoding.
---

# Serialization Skill

Rules:

1. Treat all incoming data as untrusted.
2. Validate bounds before reading.
3. Support versioning.
4. Define endian handling explicitly.
5. Avoid `reinterpret_cast` unless layout guarantees exist and alignment is checked.
6. Prefer explicit encoding.
7. Support `SerializeInto()` for buffer reuse.
8. Provide `TryGet()` APIs for hot paths.
9. Separate views from owning data.
10. Test malformed payloads, truncated payloads, unknown versions, unknown field types, and large payloads.
