---
name: cpp-dll-abi
description: Use when creating exported APIs, plugin interfaces, DLL boundaries, or transport wrappers.
---

# DLL ABI Skill

Rules:

1. Do not expose STL containers in exported interfaces unless the ABI/runtime contract is fully controlled.
2. Do not throw exceptions across module boundaries.
3. Avoid allocating in one module and freeing in another unless the allocator contract is explicit.
4. Use explicit export/import macros, for example `FOCUSTRANSPORT_API`.
5. Prefer opaque handles or pImpl for ABI stability.
6. Version exported APIs.
7. Copy external resources immediately when their lifetime is not guaranteed:
   - message payloads
   - callback data
   - transport handles
8. Document ownership explicitly.
9. Consider binary compatibility before refactoring public types.
10. Public APIs should remain migration-friendly.
