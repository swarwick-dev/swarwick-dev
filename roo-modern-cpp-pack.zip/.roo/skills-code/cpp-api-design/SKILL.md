---
name: cpp-api-design
description: Use when designing modern C++ public APIs, library interfaces, DLL wrappers, compatibility layers, or migration-friendly abstractions.
---

# C++ API Design Skill

Rules:

1. Keep public APIs small, explicit, and hard to misuse.
2. Preserve source compatibility where migration cost matters.
3. Use strong types instead of ambiguous primitive parameters.
4. Do not expose STL types across unstable DLL/plugin ABI boundaries unless both sides are built with the same compiler/runtime contract.
5. Avoid throwing exceptions across DLL boundaries.
6. Prefer pImpl for ABI-stable C++ classes.
7. Make ownership obvious from names and types.
8. Return errors consistently: status type, expected-like result, or error code.
9. Add examples for common usage.
10. Design for testability from the beginning.
