---
name: cpp-review
description: Use when reviewing pull requests, generated C++ code, refactors, or architecture changes.
---

# C++ Review Skill

Review for:

- ownership issues
- lifetime bugs
- race conditions
- missing `noexcept`
- copy vs move errors
- allocator churn
- hidden allocations
- unnecessary virtual calls
- missing const correctness
- API misuse potential
- ABI break risks
- exception safety
- serialization safety
- shutdown correctness

Provide review output grouped as:

Critical:
High:
Medium:
Low:
Suggestions:
