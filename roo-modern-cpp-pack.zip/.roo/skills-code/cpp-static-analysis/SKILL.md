---
name: cpp-static-analysis
description: Use when improving C++ quality gates, compiler warnings, clang-tidy, clang-format, sanitizers, code analysis, or CI checks.
---

# C++ Static Analysis Skill

Rules:

1. Prefer compiler warnings first, then clang-tidy and sanitizers.
2. Enable high-value warnings without making the project unusable.
3. Treat warnings in touched code seriously.
4. Use clang-format for formatting consistency.
5. Use clang-tidy for modernize, performance, bugprone, concurrency, readability, and cppcoreguidelines checks.
6. Avoid broad suppressions.
7. Prefer local suppressions with comments when suppression is justified.
8. Keep generated files and third-party code excluded from analysis.
9. Suggest CI commands that developers can also run locally.
10. Check for lifetime, ownership, narrowing conversions, uninitialized values, and concurrency hazards.
