# Roo Code Modern C++ Pack

Drop the contents of this folder into the root of a C++ workspace using Roo Code.

Included:

- `.roo/skills-code/*/SKILL.md` modern C++ skills
- `.roo/rules-code/*.md` always-on code rules
- `.clang-format`
- `.clang-tidy`

The pack is tuned for:

- C++20
- Windows/MSVC
- Visual Studio projects
- DLL/API boundaries
- transport/messaging wrappers
- serialization
- low-latency and performance-sensitive code
- unit testing and review workflows

If a project already has naming or formatting conventions, keep the project convention as the source of truth.
