using UnrealBuildTool;

public class FWSDestructionPlugin : ModuleRules
{
    public FWSDestructionPlugin(ReadOnlyTargetRules Target) : base(Target)
    {
        PCHUsage = PCHUsageMode.UseExplicitOrSharedPCHs;

        PublicDependencyModuleNames.AddRange(new string[] {
            "Core", "CoreUObject", "Engine", "InputCore", "ChaosSolverEngine", "GeometryCollectionEngine", "Networking", "NetCore"
        });

        PrivateDependencyModuleNames.AddRange(new string[] { });
    }
}
