#pragma once

#include "CoreMinimal.h"
#include "Components/ActorComponent.h"
#include "FWSDestructibleActor.h"
#include "DynamicDestructibleComponent.generated.h"

UCLASS(ClassGroup = (Custom), meta = (BlueprintSpawnableComponent))
class FWSDESTRUCTIONPLUGIN_API UDynamicDestructibleComponent : public UActorComponent
{
    GENERATED_BODY()

public:
    UPROPERTY(EditAnywhere, BlueprintReadOnly)
    TSubclassOf<AFWSDestructibleActor> DestructibleActorClass;

    UPROPERTY(EditAnywhere)
    float DefaultDamage = 100.f;

    UFUNCTION(BlueprintCallable)
    void ReplaceWithDestructible(FVector HitLoc, FVector Impulse);
};
