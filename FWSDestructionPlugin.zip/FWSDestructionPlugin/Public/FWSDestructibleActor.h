#pragma once

#include "CoreMinimal.h"
#include "GameFramework/Actor.h"
#include "GeometryCollection/GeometryCollectionComponent.h"
#include "FWSDestructibleActor.generated.h"

UCLASS()
class FWSDESTRUCTIONPLUGIN_API AFWSDestructibleActor : public AActor
{
    GENERATED_BODY()

public:
    AFWSDestructibleActor();

    UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Destruction")
    TObjectPtr<UGeometryCollectionComponent> GeometryComp;

    UPROPERTY(ReplicatedUsing = OnRep_Destruct)
    bool bDestroyed = false;

    UFUNCTION(NetMulticast, Reliable)
    void Multicast_ApplyDestruction(FVector HitLoc, FVector Impulse, float Damage);

    void TriggerDestruction(FVector HitLoc, FVector Impulse, float Damage);

protected:
    virtual void BeginPlay() override;
    virtual void GetLifetimeReplicatedProps(TArray<FLifetimeProperty>& OutLifetimeProps) const override;

    UFUNCTION()
    void OnRep_Destruct();
};
