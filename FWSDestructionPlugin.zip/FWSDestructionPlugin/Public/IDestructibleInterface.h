#pragma once

#include "CoreMinimal.h"
#include "UObject/Interface.h"
#include "IDestructibleInterface.generated.h"

UINTERFACE(Blueprintable)
class UFWSDestructibleInterface : public UInterface
{
    GENERATED_BODY()
};

class IFWSDestructibleInterface
{
    GENERATED_BODY()

public:
    UFUNCTION(BlueprintNativeEvent, BlueprintCallable, Category = "Destruction")
    void ApplyDestruction(float DamageAmount, FVector HitLocation, FVector Impulse);
};
