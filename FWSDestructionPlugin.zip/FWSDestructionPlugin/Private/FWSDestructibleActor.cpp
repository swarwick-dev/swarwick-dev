#include "FWSDestructibleActor.h"
#include "Net/UnrealNetwork.h"

AFWSDestructibleActor::AFWSDestructibleActor()
{
    PrimaryActorTick.bCanEverTick = false;
    bReplicates = true;

    GeometryComp = CreateDefaultSubobject<UGeometryCollectionComponent>(TEXT("GeometryCollectionComponent"));
    GeometryComp->SetIsReplicated(true);
    RootComponent = GeometryComp;
}

void AFWSDestructibleActor::BeginPlay()
{
    Super::BeginPlay();
}

void AFWSDestructibleActor::TriggerDestruction(FVector HitLoc, FVector Impulse, float Damage)
{
    if (HasAuthority())
    {
        Multicast_ApplyDestruction(HitLoc, Impulse, Damage);
    }
}

void AFWSDestructibleActor::Multicast_ApplyDestruction_Implementation(FVector HitLoc, FVector Impulse, float Damage)
{
    if (bDestroyed || !GeometryComp) return;

    GeometryComp->ApplyDamage(HitLoc, Impulse, Damage);
    bDestroyed = true;
}

void AFWSDestructibleActor::OnRep_Destruct()
{
    // Visuals for clients joining later
}

void AFWSDestructibleActor::GetLifetimeReplicatedProps(TArray<FLifetimeProperty>& OutLifetimeProps) const
{
    Super::GetLifetimeReplicatedProps(OutLifetimeProps);
    DOREPLIFETIME(AFWSDestructibleActor, bDestroyed);
}
