#include "DynamicDestructibleComponent.h"
#include "Kismet/GameplayStatics.h"

void UDynamicDestructibleComponent::ReplaceWithDestructible(FVector HitLoc, FVector Impulse)
{
    if (!GetOwner()->HasAuthority() || !DestructibleActorClass) return;

    FTransform SpawnTransform = GetOwner()->GetActorTransform();
    AFWSDestructibleActor* Spawned = GetWorld()->SpawnActor<AFWSDestructibleActor>(DestructibleActorClass, SpawnTransform);
    if (Spawned)
    {
        Spawned->Multicast_ApplyDestruction(HitLoc, Impulse, DefaultDamage);
        GetOwner()->Destroy();
    }
}
